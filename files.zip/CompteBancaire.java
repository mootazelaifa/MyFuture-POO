public class CompteBancaire {

    // Attributs privés
    private String numeroCompte;
    private double solde;
    private Client titulaire;

    // Attribut static : partagé par tous les comptes
    private static int nombreComptes = 0;

    // Constructeur
    public CompteBancaire(String numeroCompte, double soldeInitial, Client titulaire) {
        this.numeroCompte = numeroCompte;
        this.solde = soldeInitial;
        this.titulaire = titulaire;
        nombreComptes++; // un compte de plus
    }

    // Getters
    public String getNumeroCompte() {
        return numeroCompte;
    }

    public double getSolde() {
        return solde;
    }

    public Client getTitulaire() {
        return titulaire;
    }

    // Setter (seulement pour le titulaire)
    public void setTitulaire(Client titulaire) {
        this.titulaire = titulaire;
    }

    // Getter static
    public static int getNombreComptes() {
        return nombreComptes;
    }

    // Déposer de l'argent
    public void deposer(double montant) {
        if (montant > 0) {
            solde = solde + montant;
            System.out.println("Dépôt de " + montant + " TND effectué sur le compte " + numeroCompte + ".");
        } else {
            System.out.println("Erreur : le montant doit être positif !");
        }
    }

    // Retirer de l'argent
    public void retirer(double montant) {
        if (montant > 0 && montant <= solde) {
            solde = solde - montant;
            System.out.println("Retrait de " + montant + " TND effectué sur le compte " + numeroCompte + ".");
        } else {
            System.out.println("Échec : Solde insuffisant sur le compte " + numeroCompte
                    + " (Solde actuel : " + solde + " TND).");
        }
    }

    // Virement vers un autre compte
    public void virement(CompteBancaire destination, double montant) {
        System.out.println("\n Tentative de virement de " + montant + " TND vers le compte "
                + destination.getNumeroCompte() + "...");
        if (montant > 0 && montant <= solde) {
            this.retirer(montant);
            destination.deposer(montant);
            System.out.println("Virement réussi !");
        } else {
            System.out.println("Virement échoué : solde insuffisant ou montant invalide.");
        }
    }

    // Afficher les détails du compte
    public void afficherDetails() {
        System.out.println("Compte N° : " + numeroCompte);
        System.out.print("Titulaire : ");
        titulaire.afficherClient();
        System.out.println("Solde Actuel : " + solde + " TND");
    }
}
